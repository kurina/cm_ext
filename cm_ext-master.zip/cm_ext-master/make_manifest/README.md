Cloudera Parcel Repository Manifest Creator
===========================================

The manifest creator will create a manifest.json file for
a directory of parcels, so that directory can be served as
a parcel repository.

Requirements
------------

* Python 2.7/3.3 or later


Running make_manifest
---------------------

```bash
$ python make_manifest/make_manifest.py <path to directory>
```

